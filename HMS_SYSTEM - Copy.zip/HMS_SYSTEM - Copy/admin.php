

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            max-width: 400px;
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        form h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        form label {
            font-size: 14px;
            color: #333;
            display: block;
            margin-bottom: 5px;
        }
        form input[type="text"],
        form input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }
        form input[type="submit"] {
            width: 90%;
            padding: 10px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        form input[type="submit"]:hover {
            background-color: #555;
        }
        .butt {
            position: absolute;
            top: 20px;
            left: 20px;
            margin-left:10%;
            text-align: center;
            text-decoration: none;
            height: 40px;
        }
    </style>
</head>
<body>
<div class="butt"><button onclick="window.location.href='page.php'">go back to page</button></div>
    <form action="" method="post">
        <h1>login as admin</h1>
        <label for="name">name:</label>
        <input type="text" id="name" name="name" required>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <button type="submit" name="login">login</button>
    </form>
</body>
</html>
<?php
$conn = mysqli_connect("localhost", "root", "", "hms_system");
if (isset($_POST['login'])) {
    $name = $_POST['name']; 
    $password = $_POST['password']; 
    $sql = "SELECT * FROM `admin` WHERE `name` = '$name' AND `password` = '$password'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        $_SESSION['name'] = $name; 
      
        header("Location: adminreport.php"); 
        exit();
    } else {
        echo "<p style='color: red; text-align: center;'>Invalid username or password.</p>";
    }
}
?>
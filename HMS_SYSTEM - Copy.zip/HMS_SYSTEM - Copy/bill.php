
<?php
$conn = mysqli_connect("localhost","root","","hms_system");
if (isset($_POST['submit'])) {
    $bill_amount = $_POST['bill_amount'];
    $payment_method = $_POST['payment_method'];
    
    
    $sql = "INSERT INTO `bill` (`bill_amount`, `payment_method`) VALUES ('$bill_amount', '$payment_method')";
    $result = mysqli_query($conn, $sql);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            max-width: 400px;
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        form h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        form label {
            font-size: 14px;
            color: #333;
            display: block;
            margin-bottom: 5px;
        }
        form input[type="text"],
        form select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }
        form input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        form input[type="submit"]:hover {
            background-color: #555;
        }
        button{
            width: 90%;
            padding: 10px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .but{
            display: flex;
            justify-content: center;
            align-items: center;
            height: 10vh;
            margin-bottom: 40%;
            margin-right: 30%;
            text-transform: uppercase;
            text-decoration: none;
          
            }
            .but a{
                text-decoration: none;
                color: white;
                text-transform: uppercase;
                text-decoration: none;
            }
    </style>
</head>
<body>
<div class="but"> <button type="button" ><a href="page.php">Go back to page</a></button></div>
    <form action="" method="post">
        <h1>Billing Form</h1>
        
        <label for="bill_amount">Bill Amount:</label>
        <input type="text" id="bill_amount" name="bill_amount" placeholder="Enter bill amount" required>
        
        <label for="payment_method">Payment Method:</label>
        <input type="text" name="payment_method" required>        
        <button name="submit">submit</button>
    </form>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>patint report</title>
    <style>
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #f4f4f9;
        }
        h1 {
            text-align: center;
            margin-top: 20px;
        }
        button {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    
    <h1>doctor report</h1>
    <button onclick="window.location.href='doctor.php'" color:blue;>Back to patient registrations</button>

    <?php
    $conn = mysqli_connect("localhost", "root", "", "hms_system");
 $sql= " SELECT *FROM `patient`";
  $result = mysqli_query($conn, $sql);
  ?>
  <table border="2" width="50%">
  <tr>
    <td>id</td> 
     <td>name</td>
    <td>age</td>
    <td>gender</td>
    <td>illness</td>

  
  </tr>

  
   
    <?php
        while($row = mysqli_fetch_assoc($result)){
        ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['age']; ?></td>
                <td><?php echo $row['gender']; ?></td>
                <td><?php echo $row['illness']; ?></td>

            </tr>
            <?php
                
            }
            ?>
        </table>

</body>
</html>
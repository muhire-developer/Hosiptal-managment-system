<?php
$conn = mysqli_connect("localhost", "root", "", "hms_system");
if (isset($_POST['submit'])) {
    $specialist = $_POST['specialist']; 
    $schedule = $_POST['schedule']; 
     $assigned_patients = $_POST['assigned_patients']; 
    
    $sql = "SELECT * FROM `register` WHERE `username` = '$username' AND `password` = '$password'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        $_SESSION['username'] = $username; 
        header("Location: medical.php"); 
        exit();
    } else {
        echo "<p style='color: red; text-align: center;'>Invalid username or password.</p>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            max-width: 400px;
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        form h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        form label {
            font-size: 11px;
            color: #333;
            display: block;
            margin-bottom: 5px;
        }
        form input[type="text"],
        form input[type="date"],
        form select {
            width: 90%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }
        form input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        form input[type="submit"]:hover {
            background-color: #555;
        }
        button {
            width: 90%;
            padding: 10px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .but{
            position: absolute;
            top: 20px;
            left: 20px;
            text-align: center;
            text-decoration: none;
            font-size: 40px;
            text-decoration: none;
            color: #333;
            text-transform: uppercase;
        }
        .but a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
            text-decoration: none;


        }
        
    </style>
</head>
<body>
   <div class="but"> <button type="button" ><a href="page.php">Go back to page</a></button></div>
    <form action="" method="post">
        <h1>DOCTOR REGISTRATION</h1>
        
        <label for="specialist">Specialist:</label>
        <input type="text" id="specialist" name="specialist" placeholder="e.g., Cardiologist" required>
        
        <label for="name">names:</label>
        <input type="text" id="schedule" name="names" required>
        <button name="submit">submit</button>
    </form>
</body>
</html>
<?php
$conn = mysqli_connect("localhost", "root", "", "hms_system"); 
if (isset($_POST['submit'])) {
    $specialist = $_POST['specialist'];
    $name = $_POST['name'];
    $sql="INSERT INTO `doctor`VALUES( NULL,'$specialist','$name')";

    $res = mysqli_query($conn, $sql);
    
    if ($res) {
        echo "<script>alert('Registration successful!');</script>";
        echo "<script>window.location.href='medical.php';</script>";
    } else {
        echo "<script>alert('Registration failed. Please try again.');</script>";
    }
}
?>
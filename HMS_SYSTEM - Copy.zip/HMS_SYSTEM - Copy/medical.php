<?php
$connect = mysqli_connect("localhost","root", "", "hms_system");
if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $type = $_POST['type'];
   
    $query = "INSERT INTO `medical` ( `name`, `type`) VALUES ('$name', '$type');";
    $result = mysqli_query($connect, $query);
}
header("localhost:docreport.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical Records</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            max-width: 500px;
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-left: 20px;
        }
        form h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        form label {
            font-size: 14px;
            color: #333;
            display: block;
            margin-bottom: 5px;
        }
        form input[type="text"],
        form select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }
        form input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        form input[type="submit"]:hover {
            background-color: #555;
        }
        button {
            width: 90%;
            padding: 10px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .but{
            position: absolute;
            top: 15px;
            left: 10px;

        }
        
        .but a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
            text-decoration: none;
            display:flex;
            justify-content: right;
            align-items: right;
            margin-left: 10px;


        }
    </style>
</head>
<body>
    <div class="but"><button onclick="window.location.href='doctor.php'"><a href="page.php">go back to doctor</a></button></div>
         <form action="viewdoc.php" method="post">
        <h1>Medical Records</h1>
         <label for="name">name:</label>
        <input type="text" name="name" required>
        <label for="type">type:</label>
      <input type="text" name="type" required>
      <button name="submit">submit</button>
    </form>
</body>
</html>
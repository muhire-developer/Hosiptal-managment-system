<?php
session_start(); 


if (!isset($_SESSION['username'])) {
    header("Location: index.php"); 
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page</title>
    <style>
        nav {
            background-color: #333;
            overflow: hidden;
        }
        nav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
        nav a:hover {
            background-color: blue;
            color: black;
        }
        h1 {
            text-align: left;
            color: #333;
            font-family: Arial, sans-serif;
            margin-top: 20px;
            padding: 10px;
        }
        
        .content {
            max-width: 300px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            row-gap: 20px;
            margin: 20px auto;
            padding: 40px;
            margin-right:150px;
            margin-top:30px;
            background-color: #f9f9f9;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            font-family: Arial, sans-serif;
            color: #333;
            line-height: 1.6;
            background-color: #f4f4f4;

        }
        .content h2 {
            color: #333;
            font-size: 24px;
            margin-bottom: 10px;
        }
        .content p {
            margin-bottom: 15px;
        }
        .active{
            background-color: black;
            color: white;
        }
        .active:hover{
            background-color: white;
            color: black;
        }
        .img{
            background-image: url('hms.jpg');
            height: 510px;
            width: 100%;
            background-size: cover;
            background-position: center;
            margin-top: 0px;
        }
    </style>
</head>
<body>
    <h1>Welcome to the Dashboard, <?php echo $_SESSION['username']; ?>!</h1>
    <nav>
    <a href="recelogin.php">RECEPTIONIST</a>
    <a href="doctor.php">DOCTOR</a>
    <a href="bill.php">BILLING</a>
    <a href="staff.php">STAFF MGT</a>
     <a href="admin.php">ADMIN</a>
    <a href="logout.php" onclick="window.alert('Are you ready to logout?')">LOGOUT</a>
</nav>
    <div class="content">
        <p>This is the dashboard where you can manage the HMS System.</p>
    </div>
</body>
</html>
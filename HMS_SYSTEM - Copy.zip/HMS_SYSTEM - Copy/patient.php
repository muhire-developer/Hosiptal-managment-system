<?php
$conn = mysqli_connect("localhost", "root", "", "hms_system"); 
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $illness = $_POST['illness'];
    $sql="INSERT INTO `patient`( `name`, `age`, `gender`, `illness`) 
    VALUES ('$name','$age','$gender','$illness');";

    $res = mysqli_query($conn, $sql);
    
    if ($res) {
        echo "<script>alert('Registration successful!');</script>";
        echo "<script>window.location.href='patient.php';</script>";
    } else {
        echo "<script>alert('Registration failed. Please try again.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            max-width: 400px;
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        form h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        form label {
            font-size: 14px;
            color: #333;
            display: block;
            margin-bottom: 5px;
        }
        form input[type="text"],
        form input[type="gender"],
        form input[type="illeness"] {
            width: 90%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }
        form input[type="button"] {
            width: 90%;
            padding: 10px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        form input[type="button"]:hover {
            background-color: #555;
        }
        button {
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100px;
            height: 35px;

        }
        .but{
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 20px;
          
            margin-bottom:40%;
            margin-left: 20%;
            text-transform: uppercase;
            text-decoration: none;

        }
        .but a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
            text-decoration: none;


        }
    </style>
</head>
<body>
<div class="but"> <button type="button" ><a href="page.php">Go back to page</a></button></div>
    <form action="patient.php" method="post">
        <h1></h1>
        <h1>Patient Registration</h1>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="age">Age:</label>
        <input type="text" id="age" name="age" required>

        <label for="gender">Gender:</label>
        <input type="gender" id="gender" name="gender" required>

        <label for="illness">Illness:</label>
        <input type="illness" id="illness" name="illness" required>
        <button name="submit" name="submit">submit</button>
        
    </form>
</body>
</html>
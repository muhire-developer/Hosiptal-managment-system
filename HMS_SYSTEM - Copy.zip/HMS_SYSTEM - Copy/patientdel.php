<?php
$conn = mysqli_connect("localhost","root","","hms_system");
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $sql = "DELETE FROM `patient` WHERE id='$id'";
    $result = mysqli_query($conn, $sql);
   
} 
 header("Location: recreport.php");
?>
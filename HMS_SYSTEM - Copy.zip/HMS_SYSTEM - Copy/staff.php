<?php
$conn = mysqli_connect("localhost","root","","hms_system");
if(isset($_POST['submit'])) {
    $name = $_POST['name'];
    $department = $_POST['department'];
    
    $query = "INSERT INTO `staff` (`name`, `department`) VALUES ('$name', '$department')";
    $result = mysqli_query($conn, $query);
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            max-width: 400px;
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-left: 5%;
  
            }
        form h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        form label {
            font-size: 14px;
            color: #333;
            display: block;
            margin-bottom: 5px;
        }
        form input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }
        form button {
            width: 100%;
            padding: 10px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        form button:hover {
            background-color: #555;
        }
        .but {
                text-decoration: none;
                color: white;
                text-transform: uppercase;
                text-decoration: none;
                margin-right: 40%;
                margin-bottom: 40%;  
                      }
    </style>
</head>
<body>
    <div class="but"><button type="button"><a href="page.php">go back to page</a></button></div>
    <form action="" method="post">
        <h1>Staff Registration</h1>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="department">Department:</label>
        <input type="text" id="department" name="department" required>

        <button name="submit">Submit</button>
    </form>
</body>
</html>
<?php
$conn = mysqli_connect("localhost", "root", "", "hms_system");
if (isset($_POST['login'])) {
    $name = $_POST['name']; 
    $department = $_POST['department']; 
    $sql = "SELECT * FROM `staff` WHERE `name` = '$name' AND `department` = '$department'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        $_SESSION['name'] = $name; 
        header("Location: admin.php"); 
        exit();
    } else {
        echo "<p style='color: red; text-align: center;'>Invalid username or password.</p>";
    }
}
?>